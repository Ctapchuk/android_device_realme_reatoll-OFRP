############################################
# File for checking magisk version
############################################

MAGISK_VER="Alpha-27.0"
MAGISK_VER_CODE=23001
